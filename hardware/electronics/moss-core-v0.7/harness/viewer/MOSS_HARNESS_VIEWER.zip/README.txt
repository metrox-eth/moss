MOSS CORE V0.7 harness study
Open MOSS_HARNESS_VIEWER.html in a desktop WebGL browser. No server required.
This is a visual prototype, not a fabrication-approved harness.
STOP -> J8. Battery -> XT30 J10. USB is separate.
